<?php

require_once "Interfaces.php";

class Snow implements Ground
{

    public function getType ()
    {
        return "Schnee";
    }
}

?>
