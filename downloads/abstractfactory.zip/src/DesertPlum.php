<?php

require_once "Interfaces.php";

class DesertPlum implements Plant
{
    public function getType ()
    {
        return "Wüstenpflaume";
    }
}

?>
