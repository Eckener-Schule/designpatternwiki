<?php

require_once "Interfaces.php";

class DuneWorm implements Animal
{

    public function getType ()
    {
        return "Dünenwurm";
    }
}

?>
