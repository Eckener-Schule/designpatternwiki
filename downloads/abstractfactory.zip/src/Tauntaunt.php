<?php

require_once "Interfaces.php";

class Tauntaunt implements Animal
{

    public function getType ()
    {
        return "Tauntaunt";
    }
}

?>
