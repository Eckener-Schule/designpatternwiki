<?php

interface Animal
{
    public function getType ();
}

interface Plant
{
    public function getType ();
}

interface Ground
{
    public function getType ();
}

?>
