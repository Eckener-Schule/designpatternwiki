<?php

interface AbstractCreator
{
    public function createAnimal ();
    public function createPlant ();
    public function createGround ();
}

?>
