<?php

class HothGenerator implements AbstractCreator
{
    public function createAnimal ()
    {
        return new Tauntaunt;
    }

    public function createPlant ()
    {
        return new Iceplant;
    }

    public function createGround ()
    {
        return new Snow;
    }
}

?>
