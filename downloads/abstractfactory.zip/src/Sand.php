<?php

require_once "Interfaces.php";

class Sand implements Ground
{
    public function getType ()
    {
        return "Sand";
    }
}

?>
