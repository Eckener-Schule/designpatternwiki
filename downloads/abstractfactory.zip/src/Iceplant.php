<?php

require_once "Interfaces.php";

class Iceplant implements Plant
{

    public function getType ()
    {
        return "Eispflanze";
    }
}

?>
