<?php

class TatooineGenerator implements AbstractCreator
{
    public function createAnimal ()
    {
        return new DuneWorm;
    }

    public function createPlant ()
    {
        return new DesertPlum;
    }

    public function createGround ()
    {
        return new Sand;
    }
}

?>
