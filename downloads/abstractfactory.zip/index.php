<!doctype html>
<html>
<head>
<meta title="Abstract Factory Example" />
<meta charset="utf-8" />
</head>
<body>                   
<?php

# prepare autoloader
define ('BASEPATH', realpath(dirname(__FILE__)));
spl_autoload_register(function ($class){require_once BASEPATH.DIRECTORY_SEPARATOR.'src'.DIRECTORY_SEPARATOR. $class . '.php';});

# Hoth example
$generator = new HothGenerator;

$animal = $generator->createAnimal ();
$plant = $generator->createPlant ();
$ground = $generator->createGround ();

printf ('<h1>Hoth</h1><br />');
printf ('<strong>Tier:</strong> Ich bin ein %s.<br />', $animal->getType ());
printf ('<strong>Pflanze:</strong> Ich bin eine %s.<br />', $plant->getType ());
printf ('<strong>Untergrund:</strong> Ich bin %s.<br />', $ground->getType ());
printf ('<br /><hr /><br />');

# Tattooine example
$generator = new TatooineGenerator;

$animal = $generator->createAnimal ();
$plant = $generator->createPlant ();
$ground = $generator->createGround ();

printf ('<h1>Tatooine</h1><br />');
printf ('<strong>Tier:</strong> Ich bin ein %s.<br />', $animal->getType ());
printf ('<strong>Pflanze:</strong> Ich bin eine %s.<br />', $plant->getType ());
printf ('<strong>Untergrund:</strong> Ich bin %s.<br />', $ground->getType ());
printf ('<br/><hr /><br />');

?>
</body>
</html>
