<?php
class ConcreteComponentB implements Component {
    public function operate(){
        echo 'ConcreteComponentB operates.<br>';
    }
}
