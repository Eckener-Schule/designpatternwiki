<?php

interface Component{
    public function operate();
}

?>;
