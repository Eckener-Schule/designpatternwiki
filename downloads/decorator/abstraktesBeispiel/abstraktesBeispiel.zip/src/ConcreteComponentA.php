<?php
class ConcreteComponentA implements Component {
    public function operate(){
        echo 'ConcreteComponentA operates. <br>';
    }
}
?>
