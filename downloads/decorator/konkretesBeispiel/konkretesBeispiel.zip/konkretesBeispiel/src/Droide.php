<?php

interface Droide{
    public function produce();
}

?>;
