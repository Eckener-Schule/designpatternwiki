<?php
class B1 implements Droide {
    public function produce(){
        echo 'B1-Kampfdroide wurde hergestellt. *Roger Roger* <br>';
    }
}
?>
