<?php
class B2 implements Droide {
    public function produce(){
        echo 'B2-Superkampfdroide wurde hergestellt. *Roger Roger*<br>';
    }
}
