<?php
class BX implements Droide {
    public function produce(){
        echo 'BX-Kommandodroide wurde hergestellt.<br>';
    }
}
