<?php
class B3 implements Droide {
    public function produce(){
        echo 'B3-Ultrakampfdroide wurde hergestellt.<br>';
    }
}
